# FF HEADSHOT PRO — Android starter project

โปรเจกต์ตัวอย่าง Android สำหรับฝึกเล็งเป้าจำลองและจัดเก็บค่าคำแนะนำ โดยใช้ธีมดำ-แดง

## มีอะไรในโปรเจกต์
- Android app (Java): หน้าปลดล็อกตัวอย่าง, เมนูฝึกเล็ง 30 วินาที, เป้าจำลอง, sliders สำหรับ DPI/Sensitivity, บันทึก/โหลดโปรไฟล์ในเครื่อง
- Firebase backend starter: callable functions สำหรับตรวจสอบ KEY, สร้าง KEY และเปลี่ยนสถานะ KEY
- Firestore rules ตัวอย่าง
- Admin dashboard HTML starter

## ข้อจำกัดสำคัญ
- `DEMO-2026` เป็น KEY ทดสอบแบบ local เท่านั้น ไม่ใช่ระบบคีย์จริง
- Backend และหน้า Admin ยังไม่ได้ deploy/เชื่อมกับ Firebase
- ต้องสร้าง Firebase project, ตั้ง Authentication, App Check, deploy Cloud Functions และกำหนด custom claim `admin` ผ่านสภาพแวดล้อมที่เชื่อถือได้ก่อนใช้จริง
- ไม่มี Aimbot, ESP, auto-headshot, game injection หรือการแก้ไข Free Fire
- ค่า DPI/Sensitivity เป็นค่าคำแนะนำและบันทึกในแอปเท่านั้น ไม่ได้เปลี่ยนค่าภายในเกมหรือ DPI ระบบ Android อัตโนมัติ

## Build APK
1. ติดตั้ง Android Studio และ JDK 17
2. เปิดโฟลเดอร์นี้ใน Android Studio
3. รอ Gradle Sync
4. เลือก Build > Build APK(s)
5. ไฟล์ debug APK จะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

## ก่อนปล่อยใช้งานจริง
1. ตั้งค่า Firebase project และ Authentication
2. Deploy `backend/functions` ด้วย Firebase CLI
3. ปรับ Firestore rules ตามโครงสร้างข้อมูลและทดสอบด้วย Firebase Emulator
4. เชื่อม Android กับ Firebase callable function และ App Check
5. สร้างหน้า Admin ที่เชื่อม Authentication/Functions จริง
6. ทดสอบ security rules และสิทธิ์ Admin ก่อนเผยแพร่

## Build APK automatically with GitHub Actions

This repository includes `.github/workflows/android-apk.yml`. Push the project to a GitHub repository, then open **Actions → Build Android APK → Run workflow**. When the workflow finishes, download the `FF-HEADSHOT-PRO-debug-apk` artifact and install `app-debug.apk` on Android.

### Demo access
- App demo KEY: `DEMO-2026`
- Admin dashboard: `admin/index.html` is a UI starter only. It is **not** connected to Firebase and has no working admin login. No admin password is configured in this starter project.

Do not put a real admin password or Firebase service-account credentials inside the APK. Configure Firebase Authentication and grant the admin custom claim from a trusted Admin SDK environment before using the admin backend.
