package com.ffheadshot.pro;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import android.view.Gravity;
import android.view.animation.AlphaAnimation;
import android.widget.*;
import android.graphics.Typeface;
import android.content.Context;
import java.util.Random;

public class MainActivity extends Activity {
    private static final int BG=0xFF090909, CARD=0xFF202020, RED=0xFFFF2020, WHITE=Color.WHITE;
    private SharedPreferences prefs;
    private EditText keyInput, profileInput;
    private TextView appTitle, message;
    private SeekBar general, redDot, scope2x, scope4x, sniper, dpi;
    private boolean unlocked=false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("ffhp", MODE_PRIVATE);
        showKeyGate();
    }
    private TextView label(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private LinearLayout page() {
        LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(18,18,18,18); l.setBackgroundColor(BG); return l;
    }
    private LinearLayout card(LinearLayout root) {
        LinearLayout c=new LinearLayout(this); c.setOrientation(1); c.setPadding(16,14,16,14); c.setBackgroundColor(CARD);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,8,0,8); root.addView(c,lp); return c;
    }
    private Button btn(String s) {
        Button b=new Button(this); b.setText(s); b.setTextColor(WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED)); return b;
    }
    private void showKeyGate() {
        LinearLayout root=page(); root.setGravity(Gravity.CENTER);
        TextView title=label("FF HEADSHOT PRO",28,RED,true); title.setGravity(Gravity.CENTER); root.addView(title);
        root.addView(label("TRAINING • SETTINGS • PROFILE",12,0xFFBBBBBB,true));
        LinearLayout c=card(root);
        c.addView(label("ปลดล็อกด้วย KEY",19,WHITE,true));
        keyInput=new EditText(this); keyInput.setSingleLine(true); keyInput.setHint("กรอก KEY"); keyInput.setTextColor(WHITE); keyInput.setHintTextColor(0xFF888888); c.addView(keyInput);
        Button enter=btn("ตรวจสอบ KEY"); c.addView(enter);
        message=label("โหมดตัวอย่าง: ใช้ DEMO-2026 เพื่อทดลองหน้าจอเท่านั้น",12,0xFFFFAAAA,false); c.addView(message);
        enter.setOnClickListener(v->{
            String k=keyInput.getText().toString().trim();
            // Demo-only local gate. Replace with authenticated HTTPS backend validation before release.
            if("DEMO-2026".equals(k)){unlocked=true;showHome();}
            else message.setText("KEY ไม่ถูกต้อง หรือยังไม่ได้เชื่อมต่อระบบตรวจสอบ KEY");
        });
        setContentView(root);
    }
    private void showHome() {
        LinearLayout root=page(); ScrollView sc=new ScrollView(this); sc.addView(root);
        appTitle=label(prefs.getString("app_title","FF HEADSHOT PRO"),26,RED,true); appTitle.setGravity(Gravity.CENTER); root.addView(appTitle);
        TextView sub=label("HEADSHOT TRAINING PANEL",11,0xFFBBBBBB,true); sub.setGravity(Gravity.CENTER); root.addView(sub);
        LinearLayout training=card(root); training.addView(label("ระบบฝึกเล็ง",19,WHITE,true));
        training.addView(label("ฝึกกับเป้าจำลอง ไม่เชื่อมต่อหรือควบคุม Free Fire",12,0xFFCCCCCC,false));
        Button start=btn("เริ่มฝึกเล็ง"); training.addView(start); start.setOnClickListener(v->showTraining());
        LinearLayout settings=card(root); settings.addView(label("ตั้งค่าความไว (ค่าคำแนะนำ)",19,WHITE,true));
        dpi=addSlider(settings,"DPI Preset",100,600,prefs.getInt("dpi",320));
        general=addSlider(settings,"General",1,200,prefs.getInt("general",100));
        redDot=addSlider(settings,"Red Dot",1,200,prefs.getInt("redDot",95));
        scope2x=addSlider(settings,"2X Scope",1,200,prefs.getInt("scope2x",90));
        scope4x=addSlider(settings,"4X Scope",1,200,prefs.getInt("scope4x",80));
        sniper=addSlider(settings,"Sniper Scope",1,200,prefs.getInt("sniper",60));
        Button save=btn("บันทึกโปรไฟล์"); settings.addView(save); save.setOnClickListener(v->save());
        LinearLayout profile=card(root); profile.addView(label("โปรไฟล์",19,WHITE,true));
        profileInput=new EditText(this); profileInput.setSingleLine(true); profileInput.setHint("ชื่อโปรไฟล์"); profileInput.setTextColor(WHITE); profileInput.setHintTextColor(0xFF888888);
        profileInput.setText(prefs.getString("profile","My Profile")); profile.addView(profileInput);
        Button load=btn("โหลดโปรไฟล์ล่าสุด"); profile.addView(load); load.setOnClickListener(v->load());
        Button logout=btn("ออกจากระบบ"); root.addView(logout); logout.setOnClickListener(v->{unlocked=false;showKeyGate();});
        root.startAnimation(new AlphaAnimation(0f,1f){{setDuration(350);}});
        setContentView(sc);
    }
    private SeekBar addSlider(LinearLayout parent,String name,int min,int max,int value) {
        TextView t=label(name+": "+value,13,WHITE,false); parent.addView(t);
        SeekBar s=new SeekBar(this); s.setMax(max-min); s.setProgress(Math.max(0,Math.min(max-min,value-min))); parent.addView(s);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean u){t.setText(name+": "+(p+min));}
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        }); return s;
    }
    private int v(SeekBar s,int min){return s.getProgress()+min;}
    private void save(){
        prefs.edit().putInt("dpi",v(dpi,100)).putInt("general",v(general,1)).putInt("redDot",v(redDot,1))
        .putInt("scope2x",v(scope2x,1)).putInt("scope4x",v(scope4x,1)).putInt("sniper",v(sniper,1))
        .putString("profile",profileInput.getText().toString().trim()).apply();
        Toast.makeText(this,"บันทึกโปรไฟล์แล้ว",Toast.LENGTH_SHORT).show();
    }
    private void load(){
        dpi.setProgress(prefs.getInt("dpi",320)-100); general.setProgress(prefs.getInt("general",100)-1);
        redDot.setProgress(prefs.getInt("redDot",95)-1); scope2x.setProgress(prefs.getInt("scope2x",90)-1);
        scope4x.setProgress(prefs.getInt("scope4x",80)-1); sniper.setProgress(prefs.getInt("sniper",60)-1);
        profileInput.setText(prefs.getString("profile","My Profile"));
        Toast.makeText(this,"โหลดโปรไฟล์แล้ว",Toast.LENGTH_SHORT).show();
    }
    private void showTraining(){
        LinearLayout root=page(); TextView title=label("AIM TRAINING",24,RED,true); title.setGravity(Gravity.CENTER); root.addView(title);
        AimView aim=new AimView(this); root.addView(aim,new LinearLayout.LayoutParams(-1,0,1));
        Button back=btn("กลับหน้าหลัก"); root.addView(back); back.setOnClickListener(v->showHome()); setContentView(root);
    }
    private class AimView extends View {
        Paint p=new Paint(3); Random r=new Random(); float x=180,y=180,rad=36; int score=0,seconds=30; long start=System.currentTimeMillis(); boolean done=false;
        android.os.Handler h=new android.os.Handler();
        Runnable timer=new Runnable(){public void run(){if(!done){seconds=Math.max(0,30-(int)((System.currentTimeMillis()-start)/1000));if(seconds==0)done=true;invalidate();if(!done)h.postDelayed(this,150);}}};
        AimView(Context c){super(c);setBackgroundColor(0xFF151515);h.post(timer);}
        protected void onDraw(Canvas c){super.onDraw(c);p.setColor(WHITE);p.setTextSize(30);c.drawText("คะแนน "+score,22,42,p);p.setTextSize(20);c.drawText("เวลา "+seconds,22,72,p);
            if(done){p.setColor(RED);p.setTextSize(28);c.drawText("จบการฝึก • "+score+" คะแนน",22,getHeight()/2f,p);return;}
            p.setColor(RED);c.drawCircle(x,y,rad,p);p.setColor(WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawCircle(x,y,rad-9,p);p.setStyle(Paint.Style.FILL);}
        public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()==1&&!done){float dx=e.getX()-x,dy=e.getY()-y;if(dx*dx+dy*dy<=rad*rad){score++;x=rad+r.nextInt(Math.max(1,(int)(getWidth()-2*rad)));y=100+r.nextInt(Math.max(1,(int)(getHeight()-120)));invalidate();}return true;}return true;}
    }
}
