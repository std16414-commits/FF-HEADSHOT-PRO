# Firebase backend setup (production checklist)

The Android app currently uses a **local demo key** (`DEMO-2026`) so the UI can be tested offline. This is not secure licensing and must not be used to distribute a paid/protected app.

For production:
1. Create a Firebase project.
2. Enable Firebase Authentication (email/password) for administrators.
3. Deploy Cloud Functions in `functions/`.
4. Store key hashes, not raw keys, in Firestore.
5. Set admin custom claims only from a trusted Admin SDK environment.
6. Configure Firestore rules to deny direct client writes to keys, users, and audit logs.
7. Connect the Android app to an HTTPS callable function for key validation.
8. Never place service-account JSON, private API secrets, or admin credentials in the APK.

The backend source below is a secure starting pattern, not deployed infrastructure. You must configure and deploy it in your own Firebase project.
