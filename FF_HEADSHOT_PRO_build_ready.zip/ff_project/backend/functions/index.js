const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue, Timestamp } = require('firebase-admin/firestore');
const crypto = require('crypto');

initializeApp();
const db = getFirestore();
const hashKey = (key) => crypto.createHash('sha256').update(key).digest('hex');

exports.validateLicenseKey = onCall({ enforceAppCheck: true }, async (request) => {
  const key = String(request.data?.key || '').trim();
  if (!request.auth) throw new HttpsError('unauthenticated', 'กรุณาเข้าสู่ระบบก่อน');
  if (key.length < 8 || key.length > 128) throw new HttpsError('invalid-argument', 'KEY ไม่ถูกต้อง');

  const keyHash = hashKey(key);
  const ref = db.collection('keys').doc(keyHash);
  const result = await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) return { ok: false, reason: 'invalid' };
    const data = snap.data();
    if (data.status !== 'active') return { ok: false, reason: 'disabled' };
    if (data.expiresAt && data.expiresAt.toMillis() < Date.now()) return { ok: false, reason: 'expired' };
    const uid = request.auth.uid;
    const devices = Array.isArray(data.devices) ? data.devices : [];
    if (!devices.includes(uid) && devices.length >= (data.maxDevices || 1)) return { ok: false, reason: 'device_limit' };
    if (!devices.includes(uid)) tx.update(ref, { devices: [...devices, uid] });
    tx.set(db.collection('audit').doc(), {
      action: 'key_validated', keyHash, uid, at: FieldValue.serverTimestamp()
    });
    return { ok: true };
  });
  return result;
});

exports.adminCreateKey = onCall({ enforceAppCheck: true }, async (request) => {
  if (!request.auth || request.auth.token.admin !== true)
    throw new HttpsError('permission-denied', 'เฉพาะแอดมินเท่านั้น');
  const raw = crypto.randomBytes(18).toString('base64url');
  const days = Math.max(1, Math.min(3650, Number(request.data?.days || 30)));
  const maxDevices = Math.max(1, Math.min(10, Number(request.data?.maxDevices || 1)));
  const keyHash = hashKey(raw);
  await db.collection('keys').doc(keyHash).set({
    status: 'active', maxDevices, devices: [],
    expiresAt: Timestamp.fromMillis(Date.now() + days * 86400000),
    createdAt: FieldValue.serverTimestamp(), createdBy: request.auth.uid
  });
  await db.collection('audit').add({
    action: 'key_created', keyHash, uid: request.auth.uid, at: FieldValue.serverTimestamp()
  });
  return { key: raw };
});

exports.adminSetKeyStatus = onCall({ enforceAppCheck: true }, async (request) => {
  if (!request.auth || request.auth.token.admin !== true)
    throw new HttpsError('permission-denied', 'เฉพาะแอดมินเท่านั้น');
  const keyHash = String(request.data?.keyHash || '');
  const status = String(request.data?.status || '');
  if (!/^[a-f0-9]{64}$/.test(keyHash) || !['active','banned','revoked'].includes(status))
    throw new HttpsError('invalid-argument', 'ข้อมูลไม่ถูกต้อง');
  await db.collection('keys').doc(keyHash).update({ status });
  await db.collection('audit').add({
    action: 'key_status_changed', keyHash, status, uid: request.auth.uid, at: FieldValue.serverTimestamp()
  });
  return { ok: true };
});
